local pedEntity = nil

CreateThread(function()
    local modelHash = GetHashKey(Config.NPC.model)
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do Wait(10) end
    
    lib.requestAnimDict(Config.NPC.animDict)

    pedEntity = CreatePed(0, modelHash, Config.NPC.coords.x, Config.NPC.coords.y, Config.NPC.coords.z - 1.0, Config.NPC.coords.w, false, true)
    SetEntityInvincible(pedEntity, true)
    FreezeEntityPosition(pedEntity, true)
    SetBlockingOfNonTemporaryEvents(pedEntity, true)
    TaskPlayAnim(pedEntity, Config.NPC.animDict, Config.NPC.animName, 8.0, 0.0, -1, 1, 0, 0, 0, 0)

    exports.ox_target:addBoxZone({
        coords = vec3(Config.NPC.coords.x, Config.NPC.coords.y, Config.NPC.coords.z + 1.0),
        size = vec3(4.0, 4.0, 4.0),
        rotation = Config.NPC.coords.w,
        debug = false,
        drawSprite = true,
        options = {
            {
                name = 'rs_tablice',
                label = 'Ukryj Tablice ('..Config.Price..'$)',
                icon = 'fa-solid fa-mask',
                distance = 6.0,
                canInteract = function(entity, distance, coords, name)
                    local ped = PlayerPedId()
                    if not IsPedInAnyVehicle(ped, false) then return false end
                    
                    local vehicle = GetVehiclePedIsIn(ped, false)
                    if GetPedInVehicleSeat(vehicle, -1) ~= ped then return false end

                    return true
                end,
                onSelect = function()
                    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
                    if vehicle and vehicle ~= 0 then
                        local plate = GetVehicleNumberPlateText(vehicle)
                        local netId = NetworkGetNetworkIdFromEntity(vehicle)
                        
                        TriggerServerEvent('rs-tablice:server:requestBuy', netId, plate)
                    else
                        ESX.ShowNotification('~r~Musisz być w pojeździe!')
                    end
                end
            }
        }
    })
end)

RegisterNetEvent('rs-tablice:client:startProcess', function(netId, originalPlate)
    local vehicle = NetworkGetEntityFromNetworkId(netId)
    
    if DoesEntityExist(vehicle) then
        FreezeEntityPosition(vehicle, true)

        if ESX.Progressbar then
            ESX.Progressbar('Usuwanie Tablic', 5000)
        else
            exports['esx_progressbar']:Progressbar("Usuwanie Tablic", 5000)
        end

        Wait(5000)

        FreezeEntityPosition(vehicle, false)
        SetVehicleNumberPlateText(vehicle, "        ")
        ESX.ShowNotification('~g~Tablice zostały ukryte!')
        
        CreateThread(function()
            Wait(Config.Duration * 60 * 1000)
            if DoesEntityExist(vehicle) then
                SetVehicleNumberPlateText(vehicle, originalPlate)
                ESX.ShowNotification('~y~Czas minął. Tablice wróciły.')
            end
        end)
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    if pedEntity then DeleteEntity(pedEntity) end
end)