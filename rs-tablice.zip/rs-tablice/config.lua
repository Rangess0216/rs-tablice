Config = {}

Config.Price = 10000        -- Koszt
Config.Duration = 30        -- Czas trwania (minuty)
Config.Cooldown = 60        -- Cooldown (minuty)

Config.NPC = {
    model = 'g_m_y_mexgoon_02',
    coords = vec4(258.20477294922, -786.48156738281, 30.441312789917, 25.223936080933),
    animDict = 'anim@heists@heist_corona@single_team',
    animName = 'single_team_loop_boss'
}