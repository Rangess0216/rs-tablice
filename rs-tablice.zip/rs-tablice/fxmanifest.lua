fx_version 'cerulean'
game 'gta5'

author 'Rangess0216'
description 'Ukrywanie tablic rejestracyjnych'
version '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'es_extended',
    'ox_target',
    'ox_lib'
}