local Cooldowns = {}

local function Notify(source, msg)
    TriggerClientEvent('esx:showNotification', source, msg)
end

RegisterNetEvent('rs-tablice:server:requestBuy', function(netId, originalPlate)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    
    if not xPlayer then return end

    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if not vehicle or not DoesEntityExist(vehicle) then
        return Notify(src, '~r~Błąd: Nie znaleziono pojazdu.')
    end

    local identifier = xPlayer.identifier
    local currentTime = os.time()
    
    if Cooldowns[identifier] and Cooldowns[identifier] > currentTime then
        local timeLeft = math.ceil((Cooldowns[identifier] - currentTime) / 60)
        return Notify(src, ('~r~Musisz odczekać jeszcze %s min.'):format(timeLeft))
    end

    if xPlayer.getMoney() >= Config.Price then
        xPlayer.removeMoney(Config.Price)
        Cooldowns[identifier] = currentTime + (Config.Cooldown * 60)
        
        TriggerClientEvent('rs-tablice:client:startProcess', src, netId, originalPlate)
    else
        Notify(src, ('~r~Nie masz wystarczająco gotówki (%s$).'):format(Config.Price))
    end
end)